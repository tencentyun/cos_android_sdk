package com.tencent.cos.qclouddemo;

import android.content.DialogInterface;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.tencent.cos.COS;
import com.tencent.cos.COSClient;
import com.tencent.cos.COSClientConfig;
import com.tencent.cos.model.COSEndPoint;
import com.tencent.cos.model.COSRequest;
import com.tencent.cos.model.COSResult;
import com.tencent.cos.model.CreateDirRequest;
import com.tencent.cos.model.CreateDirResult;
import com.tencent.cos.model.DeleteObjectRequest;
import com.tencent.cos.model.DeleteObjectResult;
import com.tencent.cos.model.GetObjectMetadataRequest;
import com.tencent.cos.model.GetObjectMetadataResult;
import com.tencent.cos.model.ListDirRequest;
import com.tencent.cos.model.ListDirResult;

import com.tencent.cos.model.RemoveEmptyDirRequest;
import com.tencent.cos.model.UpdateObjectRequest;
import com.tencent.cos.model.UpdateObjectResult;
import com.tencent.cos.task.listener.ICmdTaskListener;

import org.json.JSONException;
import org.json.JSONObject;

public class DirActivity extends AppCompatActivity implements View.OnClickListener{

    Button createDir, deleteDir, updateDir, statDir, listDir;
    TextView pathText, detailText;

    /** cos */
    COSClient cos;
    COSClientConfig cosConfig;
    String appid = "10006595";
    String bucket = "xy";
    volatile int requestId;
    BizServer bizServer = BizServer.getInstance();

    private Handler mHandler = new Handler(Looper.getMainLooper());

    //用于获取对话框的内容
    String getDirName = null;
    String getPrefix = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dir);

        createDir = (Button)findViewById(R.id.create);
        deleteDir = (Button)findViewById(R.id.delete);
        updateDir = (Button)findViewById(R.id.update);
        statDir = (Button)findViewById(R.id.stat);
        listDir = (Button)findViewById(R.id.listDir);

        pathText = (TextView)findViewById(R.id.cosPath);
        detailText = (TextView)findViewById(R.id.detail);

        /** cosclient 配置设置; 根据需要设置；  */
        cosConfig = new COSClientConfig();
        /** 设置园区；根据创建的cos空间时选择的园区
         * 华南园区：COSEndPoint.COS_GZ(已上线)
         * 华北园区：COSEndPoint.COS_TJ(已上线)
         * 华东园区：COSEndPoint.COS_SH
         * 此处Demo中选择了 华东园区：COSEndPoint.COS_SH用于测试
         */
        cosConfig.setEndPoint(COSEndPoint.COS_SH);
        cos = new COSClient(this,appid,cosConfig,"dir_qcloud");

        createDir.setOnClickListener(this);
        deleteDir.setOnClickListener(this);
        updateDir.setOnClickListener(this);
        statDir.setOnClickListener(this);
        listDir.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id){
            case R.id.create:
                createDir();
                break;
            case R.id.delete:
                deleteDir();
                break;
            case R.id.update:
                updateDir();
                break;
            case R.id.stat:
                statDir();
                break;
            case R.id.listDir:
                listDir();
                break;
        }
    }

    /**
     * 1)创建书写合法目录 dirName = test;
     * 2)创建书写不合法目录 dirName = test>
     * 3)创建长度非法的目录  dirName = 1234567890122345678901; dirName.length()>20
     * 4)创建子目录下的目录 dirName = test/test
     * 5)创建多级的目录 dirName = test/test/test/test/test
     * 6)创建已存在的目录 dirName = test
     * 7)创建已删除的目录
     */
    public void createDir(){
        final EditText editText = new EditText(DirActivity.this);
        AlertDialog.Builder builder = new AlertDialog.Builder(DirActivity.this);
        builder.setTitle("请输入文件夹路径");
        builder.setView(editText);
        builder.setPositiveButton("确认",new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which) {
                getDirName = editText.getText().toString().trim();
                createDir(getDirName);
            }
        });
        builder.setNegativeButton("取消",new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void createDir(final String dirName){
        new Thread(new Runnable() {
            @Override
            public void run() {
                String name = dirName;
                if(TextUtils.isEmpty(name)){
                    Toast.makeText(DirActivity.this,"文件夹名为空",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(!name.endsWith("/")){
                    name = name + "/";
                }
                final String cosPath = name;
                final String biz_attr = null;
                bizServer.setBucket(bucket);
                String sign = bizServer.getSign();
                CreateDirRequest createDirRequest = new CreateDirRequest();
                createDirRequest.setBucket(bucket);
                createDirRequest.setCosPath(cosPath);
                createDirRequest.setBiz_attr(biz_attr);
                createDirRequest.setSign(sign);
                createDirRequest.setListener(new ICmdTaskListener() {
                    @Override
                    public void onSuccess(COSRequest cosRequest, COSResult cosResult) {
                        final CreateDirResult createDirResult = (CreateDirResult) cosResult;
                        Log.w("XIAO","目录创建： ret=" + createDirResult.code + "; msg=" + createDirResult.msg );

                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                pathText.setText("/" + appid + "/" + bucket + "/" + dirName) ;
                                detailText.setText("目录创建： ret=" + createDirResult.code + "; msg=" + createDirResult.msg  +"ctime = " + createDirResult.ctime);
                            }
                        });
                    }

                    @Override
                    public void onFailed(COSRequest COSRequest, final COSResult cosResult) {
                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                pathText.setText("/" + appid + "/" + bucket + "/" + dirName) ;
                                detailText.setText("目录创建失败：ret=" + cosResult.code  + "; msg =" + cosResult.msg);
                            }
                        });
                    }
                });
                /*
                CreateDirRequest createDirRequest = new CreateDirRequest(appid, bucket,cosPath, biz_attr, sign, new ICmdTaskListener() {
                    @Override
                    public void onSuccess(COSRequest cosRequest, final COSResult cosResult) {

                        final CreateDirResult createDirResult = (CreateDirResult) cosResult;
                        Log.w("XIAO","目录创建： ret=" + createDirResult.code + "; msg=" + createDirResult.msg );

                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                pathText.setText("/" + appid + "/" + bucket + "/" + dirName) ;
                                detailText.setText("目录创建： ret=" + createDirResult.code + "; msg=" + createDirResult.msg  +"ctime = " + createDirResult.ctime);
                            }
                        });
                    }

                    @Override
                    public void onFailed(COSRequest COSRequest, final COSResult cosResult) {
                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                pathText.setText("/" + appid + "/" + bucket + "/" + dirName) ;
                                detailText.setText("目录创建失败：ret=" + cosResult.code  + "; msg =" + cosResult.msg);
                            }
                        });
                    }
                });
                */
                requestId = createDirRequest.getRequestId();
                cos.createDir(createDirRequest);
            }
        }).start();
    }

    public void deleteDir(){
        final EditText editText = new EditText(DirActivity.this);
        AlertDialog.Builder builder = new AlertDialog.Builder(DirActivity.this);
        builder.setTitle("请输入文件夹路径");
        builder.setView(editText);
        builder.setPositiveButton("确认",new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which) {
                getDirName = editText.getText().toString().trim();
                deleteDir(getDirName);
            }
        });
        builder.setNegativeButton("取消",new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void deleteDir(final String dirName){
        new Thread(new Runnable() {
            @Override
            public void run() {
                String name = dirName;
                if(TextUtils.isEmpty(name)){
                    Toast.makeText(DirActivity.this,"文件夹名为空",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(!name.endsWith("/")){
                    name = name + "/";
                }
                final String cosPath = name;
                bizServer.setBucket(bucket);
                bizServer.setFileId("/" + cosPath);
                String onceSign = bizServer.getOnceSign();

                RemoveEmptyDirRequest removeEmptyDirRequest = new RemoveEmptyDirRequest();
                removeEmptyDirRequest.setBucket(bucket);
                removeEmptyDirRequest.setCosPath(cosPath);
                removeEmptyDirRequest.setSign(onceSign);
                removeEmptyDirRequest.setListener(new ICmdTaskListener() {
                    @Override
                    public void onSuccess(COSRequest cosRequest, COSResult cosResult) {
                        final DeleteObjectResult removeEmptyDirResult = (DeleteObjectResult) cosResult;
                        Log.w("XIAO","removeDir 结果： ret=" + removeEmptyDirResult.code + "; msg=" + removeEmptyDirResult.msg );

                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                pathText.setText("/" + appid + "/" + bucket + "/" + dirName) ;
                                detailText.setText("code = " + removeEmptyDirResult.code  + "; msg=" +removeEmptyDirResult.msg );
                            }
                        });
                    }

                    @Override
                    public void onFailed(COSRequest COSRequest, final COSResult cosResult) {
                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                pathText.setText("/" + appid + "/" + bucket + "/" + dirName) ;
                                detailText.setText("目录删除失败：ret=" + cosResult.code  + "; msg =" + cosResult.msg);
                            }
                        });
                    }
                });
                /*
                DeleteObjectRequest removeEmptyDirRequest = new DeleteObjectRequest(appid,bucket,cosPath,onceSign, new ICmdTaskListener(){

                    @Override
                    public void onSuccess(COSRequest cosRequest, COSResult cosResult) {
                        final DeleteObjectResult removeEmptyDirResult = (DeleteObjectResult) cosResult;
                        Log.w("XIAO","结果： ret=" + removeEmptyDirResult.code + "; msg=" + removeEmptyDirResult.msg );

                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                pathText.setText("/" + appid + "/" + bucket + "/" + dirName) ;
                                detailText.setText("code = " + removeEmptyDirResult.code  + "; msg=" +removeEmptyDirResult.msg );
                            }
                        });
                    }

                    @Override
                    public void onFailed(COSRequest COSRequest, final COSResult cosResult) {
                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                pathText.setText("/" + appid + "/" + bucket + "/" + dirName) ;
                                detailText.setText("目录删除失败：ret=" + cosResult.code  + "; msg =" + cosResult.msg);
                            }
                        });
                    }

                });
                */
                requestId = removeEmptyDirRequest.getRequestId();
                cos.removeEmptyDir(removeEmptyDirRequest);
            }
        }).start();
    }

    /**
     * 1)目录更新：单级或多级目录
     *
     */
    public void updateDir(){
        final EditText editText = new EditText(DirActivity.this);
        AlertDialog.Builder builder = new AlertDialog.Builder(DirActivity.this);
        builder.setTitle("请输入文件夹路径");
        builder.setView(editText);
        builder.setPositiveButton("确认",new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which) {
                getDirName = editText.getText().toString().trim();
                updateDir(getDirName);
            }
        });
        builder.setNegativeButton("取消",new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void updateDir(final String dirName){
        if(TextUtils.isEmpty(getDirName)){
            Toast.makeText(this,"路径为空",Toast.LENGTH_SHORT).show();
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                String name = dirName;
                if(TextUtils.isEmpty(name)){
                    Toast.makeText(DirActivity.this,"文件夹名为空",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(!name.endsWith("/")){
                    name = name + "/";
                }
                String cosPath = name;
                bizServer.setBucket(bucket);
                bizServer.setFileId(cosPath);
                String sign = bizServer.getOnceSign();
                final String biz_attr = "目录属性更新" + dirName; //不知道目录的属性有哪些，这里随便填写的
                UpdateObjectRequest updateObjectRequest = new UpdateObjectRequest(appid, bucket, cosPath, sign, biz_attr,new ICmdTaskListener() {
                    @Override
                    public void onSuccess(COSRequest cosRequest, COSResult cosResult) {
                        final UpdateObjectResult updateObjectResult = (UpdateObjectResult) cosResult;
                        Log.w("XIAO","结果： ret=" + updateObjectResult.code + "; msg=" + updateObjectResult.msg );

                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                pathText.setText("/" + appid + "/" + bucket + "/" + dirName) ;
                                detailText.setText("code = " + updateObjectResult.code  + "; msg=" +updateObjectResult.msg  );
                            }
                        });
                    }

                    @Override
                    public void onFailed(COSRequest COSRequest, final COSResult cosResult) {
                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                pathText.setText("/" + appid + "/" + bucket + "/" + dirName) ;
                                detailText.setText("目录更新失败：ret=" + cosResult.code  + "; msg =" + cosResult.msg);
                            }
                        });
                    }

                });
                requestId = updateObjectRequest.getRequestId();
                cos.updateObject(updateObjectRequest);
            }
        }).start();
    }

    public void statDir(){
        final EditText editText = new EditText(DirActivity.this);
        AlertDialog.Builder builder = new AlertDialog.Builder(DirActivity.this);
        builder.setTitle("请输入文件夹路径");
        builder.setView(editText);
        builder.setPositiveButton("确认",new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which) {
                getDirName = editText.getText().toString().trim();
                statDir(getDirName);
            }
        });
        builder.setNegativeButton("取消",new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void statDir(final String dirName){
        new Thread(new Runnable() {
            @Override
            public void run() {
                String name = dirName;
                if(TextUtils.isEmpty(name)){
                    Toast.makeText(DirActivity.this,"文件夹名为空",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(!name.endsWith("/")){
                    name = name + "/";
                }
                String cosPath = name;
                bizServer.setBucket(bucket);
                String sign = bizServer.getSign();
                GetObjectMetadataRequest getObjectMetadataRequest = new GetObjectMetadataRequest(appid, bucket, cosPath, sign, new ICmdTaskListener() {
                    @Override
                    public void onSuccess(COSRequest request, COSResult cosResult) {
                        final GetObjectMetadataResult result = (GetObjectMetadataResult) cosResult;

                        final StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("code=" + result.code + "; msg=" +result.msg + "\n");
                        stringBuilder.append("ctime =" +result.ctime + "; mtime=" +result.mtime + "\n" );
                        stringBuilder.append("biz_attr=" + result.biz_attr == null ? "" : result.biz_attr );
                        Log.w("XIAO","结果： "+ stringBuilder.toString() );
                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                pathText.setText("/" + appid + "/" + bucket + "/" + (dirName == null ?"":dirName)) ;
                                detailText.setText(stringBuilder.toString());
                            }
                        });
                    }

                    @Override
                    public void onFailed(COSRequest request, final COSResult cosResult) {
                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                pathText.setText("/" + appid + "/" + bucket + "/" + (dirName == null ?"":dirName)) ;
                                detailText.setText("目录查询失败：ret=" + cosResult.code  + "; msg =" + cosResult.msg);
                            }
                        });
                    }
                });
                requestId = getObjectMetadataRequest.getRequestId();
                cos.getObjectMetadata(getObjectMetadataRequest);

            }
        }).start();

    }

    /**
     * 1)bucket根目录自动展示   cosPath = "/"
     * 2）指定目录下的目录列表展示  cosPath = "test/"
     * 3）指定目录下存在文件和目录的展示   cosPath = "test/"
     * 4）指定目录下无目录和文件的展示     cosPath = "test/"
     * 5）单级木录下 或多级目录下的展示    cosPath = "test/"
     * 6）目录前缀查询，存在的关键子       cosPath = "test/" ;  listDirRequest.setPrefix("t");
     * 7）目录前缀查询，不存在的关键字     cosPath = "test/" ;  listDirRequest.setPrefix("t");
     * 8）目录前缀查询，单级和多级
     * 9）目录前缀查询，只存在子目录或只存在子文件或都存在   cosPath = "test/" ;  listDirRequest.setPrefix("t");
     * 10）设置显示数值，1, 10, 100
     */

    public void listDir(){
        final EditText editText = new EditText(DirActivity.this);
        final CheckBox checkBox = new CheckBox(DirActivity.this);
        final EditText perfixText = new EditText(DirActivity.this);
        perfixText.setEnabled(false);
        checkBox.setText("开启前缀查询");
        checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!checkBox.isSelected()){
                    checkBox.setSelected(true);
                }
                perfixText.setEnabled(true);
            }
        });
        LinearLayout linearLayout = new LinearLayout(DirActivity.this);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.addView(editText);
        linearLayout.addView(checkBox);
        linearLayout.addView(perfixText);

        AlertDialog.Builder builder = new AlertDialog.Builder(DirActivity.this);
        builder.setTitle("请输入文件夹路径");
        builder.setView(linearLayout);
        builder.setPositiveButton("确认",new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which) {
                getDirName = editText.getText().toString().trim();
                getPrefix = perfixText.getText().toString().trim();
                Log.w("XIAO","checkBox ==" + checkBox.isSelected());
                if(!TextUtils.isEmpty(getPrefix)){
                    listDir(getDirName,getPrefix);
                }else{
                    listDir(getDirName,null);
                }
            }
        });
        builder.setNegativeButton("取消",new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void listDir(final String dirName, final String prefix){
        new Thread(new Runnable() {
            @Override
            public void run() {

                String name = dirName;
                if(TextUtils.isEmpty(dirName)){
                    name = "/";
                }else{
                    if(!name.endsWith("/")){
                        name = name + "/";
                    }
                }
                String cosPath = name;
                bizServer.setBucket(bucket);
                String sign = bizServer.getSign();
                ListDirRequest listDirRequest = new ListDirRequest();
                listDirRequest.setBucket(bucket);
                listDirRequest.setCosPath(cosPath);
                listDirRequest.setNum(100);
                listDirRequest.setContent("");
                listDirRequest.setSign(sign);
                listDirRequest.setListener(new ICmdTaskListener() {
                    @Override
                    public void onSuccess(COSRequest cosRequest, COSResult cosResult) {
                        final ListDirResult listObjectResult = (ListDirResult) cosResult;
                        Log.w("XIAO","结果： ret=" + listObjectResult.code + "; msg=" + listObjectResult.msg );
                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                pathText.setText("/" + appid + "/" + bucket + "/" + (dirName == null ? "": dirName)) ;
                            }
                        });
                        showListDir(listObjectResult);
                    }

                    @Override
                    public void onFailed(COSRequest COSRequest, final COSResult cosResult) {
                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                pathText.setText("/" + appid + "/" + bucket + "/" + (dirName == null ? "": dirName)) ;
                                detailText.setText("目录查询失败：ret=" + cosResult.code  + "; msg =" + cosResult.msg);
                            }
                        });
                    }
                });
                /*
                ListDirRequest listDirRequest = new ListDirRequest(appid,bucket,cosPath,100,"",sign,new ICmdTaskListener(){

                    @Override
                    public void onSuccess(COSRequest cosRequest, COSResult cosResult) {
                        final ListDirResult listObjectResult = (ListDirResult) cosResult;
                        Log.w("XIAO","结果： ret=" + listObjectResult.code + "; msg=" + listObjectResult.msg );
                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                pathText.setText("/" + appid + "/" + bucket + "/" + (dirName == null ? "": dirName)) ;
                            }
                        });
                        showListDir(listObjectResult);
                    }

                    @Override
                    public void onFailed(COSRequest COSRequest, final COSResult cosResult) {
                        mHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                pathText.setText("/" + appid + "/" + bucket + "/" + (dirName == null ? "": dirName)) ;
                                detailText.setText("目录查询失败：ret=" + cosResult.code  + "; msg =" + cosResult.msg);
                            }
                        });
                    }
                });
                */
                if(prefix != null){
                    listDirRequest.setPrefix(prefix);
                }
               Log.w("XIAO","prefix =" + (prefix == null ? "null" : prefix));
                requestId = listDirRequest.getRequestId();
                cos.listDir(listDirRequest);
            }
        }).start();
    }

    public void showListDir( ListDirResult listObjectResult){
        //文件夹 =》不含有  filesize 或 sha 或 access_url 或 souce_url
        StringBuilder stringBuilder = new StringBuilder("目录列表查询结果如下：");
        stringBuilder.append("code =" + listObjectResult.code + "; msg =" + listObjectResult.msg + "\n");
        stringBuilder.append("list是否结束：").append(listObjectResult.listover).append("\n");
        stringBuilder.append("content = " + listObjectResult.context + "\n");
        if(listObjectResult.infos != null && listObjectResult.infos.size() > 0){
            int length = listObjectResult.infos.size();
            String str;
            JSONObject jsonObject;
            StringBuilder fileStringBuilder = new StringBuilder();
            StringBuilder dirStringBuilder = new StringBuilder();
            for(int i = 0; i < length; i++){
                str = listObjectResult.infos.get(i);
                try {
                    jsonObject = new JSONObject(str);
                    if(jsonObject.has("sha")){
                        //是文件
                        fileStringBuilder.append("文件：" + jsonObject.optString("name")).append("\n");
                    }else{
                        //是文件夹
                        dirStringBuilder.append("文件夹： " + jsonObject.optString("name")).append("\n");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            stringBuilder.append(fileStringBuilder);
            stringBuilder.append(dirStringBuilder);
        }else{
            stringBuilder.append("该目录下无内容");
        }
        final String strResult = stringBuilder.toString();
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                detailText.setText(strResult);
            }
        });
    }
}
