package com.tencent.cos.qclouddemo;

import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.tencent.cos.COS;
import com.tencent.cos.COSClient;
import com.tencent.cos.COSClientConfig;
import com.tencent.cos.model.COSEndPoint;
import com.tencent.cos.model.COSRequest;
import com.tencent.cos.model.COSResult;
import com.tencent.cos.model.HeadBucketRequest;
import com.tencent.cos.model.HeadBucketResult;
import com.tencent.cos.task.listener.ICmdTaskListener;

public class OtherActivity extends AppCompatActivity implements View.OnClickListener {

        private Button bucketBtn, keyBtn;
        private TextView detailText, pathText;


        private Handler mainHandler = new Handler(Looper.getMainLooper());

        /**
         * cos
         */
        COSClient cos;
        COSClientConfig cosConfig;
        String appid = "10006595";
        String bucket = "xy";
        volatile int requestId;
        BizServer bizServer = BizServer.getInstance();
        String sign = null;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_other);

                bucketBtn = (Button) findViewById(R.id.bucket);
                keyBtn = (Button) findViewById(R.id.acl);

                detailText = (TextView) findViewById(R.id.detail);
                pathText = (TextView) findViewById(R.id.cosPath);

                bucketBtn.setOnClickListener(this);
                keyBtn.setOnClickListener(this);

                /** cosclient 配置设置; 根据需要设置；  */
                cosConfig = new COSClientConfig();
                /** 设置园区；根据创建的cos空间时选择的园区
                 * 华南园区：COSEndPoint.COS_GZ(已上线)
                 * 华北园区：COSEndPoint.COS_TJ(已上线)
                 * 华东园区：COSEndPoint.COS_SH
                 * 此处Demo中选择了 华东园区：COSEndPoint.COS_SH用于测试
                 */
                cosConfig.setEndPoint(COSEndPoint.COS_SH);
                cos = new COSClient(this,appid,cosConfig,"bucket_qcloud");
                cos = new COSClient(this, null, null);
        }

        @Override
        public void onClick(View v) {
                int id = v.getId();
                if(R.id.bucket == id){
                        statBucket();
                        return;
                }
        }

        public void statBucket() {
                new Thread(new Runnable() {
                        @Override
                        public void run() {
                             bizServer.setBucket(bucket);
                             sign = bizServer.getSign();
                             HeadBucketRequest headBucketRequest = new HeadBucketRequest();
                             headBucketRequest.setBucket(bucket);
                             headBucketRequest.setCosPath("/");
                             headBucketRequest.setSign(sign);
                             headBucketRequest.setListener(new ICmdTaskListener() {
                                     @Override
                                     public void onSuccess(COSRequest cosRequest, COSResult cosResult) {
                                             HeadBucketResult result = (HeadBucketResult) cosResult;
                                             StringBuilder stringBuilder = new StringBuilder();
                                             stringBuilder.append("查询结果：\n" );
                                             stringBuilder.append("code =" + result.code + ";msg=" + result.msg + "\n");
                                             stringBuilder.append("authority =" + (result.authority == null ? "":  result.authority) + "\n");
                                             stringBuilder.append("ctime=" + result.ctime + "; mtime=" + result.mtime + "\n");
                                             stringBuilder.append("biz_attr =" + (result.biz_attr == null ? "": result.biz_attr) + "\n");
                                             stringBuilder.append("migrate_source_domain =" + (result.migrate_source_domain == null ? "null": result.migrate_source_domain) + "\n");
                                             stringBuilder.append("refers: ");
                                             if(result.refers != null){
                                                     for(int i = 0; i< result.refers.size(); i++){
                                                             stringBuilder.append(result.refers.get(i) + ";");
                                                     }
                                                     stringBuilder.append(";count=" +result.refers.size()+"\n");
                                             }else{
                                                     stringBuilder.append("null" + "\n");
                                             }
                                             stringBuilder.append("black_refers:");
                                             if(result.blackRefers != null){
                                                     for(int i= 0; i< result.blackRefers.size(); i++){
                                                             stringBuilder.append(result.blackRefers.get(i) + ";");
                                                     }
                                                     stringBuilder.append( ";count=" +result.blackRefers.size() + "\n");
                                             }else{
                                                     stringBuilder.append("null" + "\n");
                                             }
                                             stringBuilder.append("cname:");
                                             if(result.cname != null){
                                                     for(int i= 0; i< result.cname.size(); i++){
                                                             stringBuilder.append(result.cname.get(i) + ";");
                                                     }
                                                     stringBuilder.append(";count=" +result.cname.size()+"\n");
                                             }else{
                                                     stringBuilder.append("null" + "\n");
                                             }
                                             stringBuilder.append("跨域设置：" + (result.CORSConfiguration == null ? "null" : result.CORSConfiguration) + "\n");
                                             final String strResult = stringBuilder.toString();
                                             Log.w("XIAO",strResult);
                                             mainHandler.post(new Runnable() {
                                                     @Override
                                                     public void run() {
                                                             detailText.setText(strResult);
                                                     }
                                             });
                                     }

                                     @Override
                                     public void onFailed(COSRequest request, final COSResult cosResult) {
                                             mainHandler.post(new Runnable() {
                                                     @Override
                                                     public void run() {
                                                             detailText.setText("查询失败： code =" + cosResult.code + "; msg=" + cosResult.msg);
                                                     }
                                             });
                                     }
                             });
                             /*
                             HeadBucketRequest headBucketRequest = new HeadBucketRequest(appid, bucket, "/", sign, new ICmdTaskListener() {
                                     @Override
                                     public void onSuccess(COSRequest request, COSResult cosResult) {
                                             HeadBucketResult result = (HeadBucketResult) cosResult;
                                             StringBuilder stringBuilder = new StringBuilder();
                                             stringBuilder.append("查询结果：\n" );
                                             stringBuilder.append("code =" + result.code + ";msg=" + result.msg + "\n");
                                             stringBuilder.append("authority =" + (result.authority == null ? "":  result.authority) + "\n");
                                             stringBuilder.append("ctime=" + result.ctime + "; mtime=" + result.mtime + "\n");
                                             stringBuilder.append("biz_attr =" + (result.biz_attr == null ? "": result.biz_attr) + "\n");
                                             stringBuilder.append("migrate_source_domain =" + (result.migrate_source_domain == null ? "null": result.migrate_source_domain) + "\n");
                                             stringBuilder.append("refers: ");
                                             if(result.refers != null){
                                                     for(int i = 0; i< result.refers.size(); i++){
                                                             stringBuilder.append(result.refers.get(i) + ";");
                                                     }
                                                     stringBuilder.append(";count=" +result.refers.size()+"\n");
                                             }else{
                                                     stringBuilder.append("null" + "\n");
                                             }
                                             stringBuilder.append("black_refers:");
                                             if(result.blackRefers != null){
                                                     for(int i= 0; i< result.blackRefers.size(); i++){
                                                             stringBuilder.append(result.blackRefers.get(i) + ";");
                                                     }
                                                     stringBuilder.append( ";count=" +result.blackRefers.size() + "\n");
                                             }else{
                                                     stringBuilder.append("null" + "\n");
                                             }
                                             stringBuilder.append("cname:");
                                             if(result.cname != null){
                                                     for(int i= 0; i< result.cname.size(); i++){
                                                             stringBuilder.append(result.cname.get(i) + ";");
                                                     }
                                                     stringBuilder.append(";count=" +result.cname.size()+"\n");
                                             }else{
                                                     stringBuilder.append("null" + "\n");
                                             }
                                             stringBuilder.append("跨域设置：" + (result.CORSConfiguration == null ? "null" : result.CORSConfiguration) + "\n");
                                             final String strResult = stringBuilder.toString();
                                             Log.w("XIAO",strResult);
                                             mainHandler.post(new Runnable() {
                                                     @Override
                                                     public void run() {
                                                             detailText.setText(strResult);
                                                     }
                                             });
                                     }

                                     @Override
                                     public void onFailed(COSRequest request, final COSResult cosResult) {
                                             mainHandler.post(new Runnable() {
                                                     @Override
                                                     public void run() {
                                                             detailText.setText("查询失败： code =" + cosResult.code + "; msg=" + cosResult.msg);
                                                     }
                                             });
                                     }
                             });
                             */
                                requestId = headBucketRequest.getRequestId();
                                cos.headBucket(headBucketRequest);
                        }

                }).start();
        }
}
