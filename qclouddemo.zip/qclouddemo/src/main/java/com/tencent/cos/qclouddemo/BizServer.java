package com.tencent.cos.qclouddemo;

import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

/**
 * Created by bradyxiao on 2016/9/13.
 */
public class BizServer {
    public static class DefaultCfg{
        public static String appid = "10006595";
        public static String bucket = "xy";
        public static String httpProtocol = "http://";
        public static String dosmain = "sh.file.myqcloud.com";
        public static String serverFlag = "/files/v2";
    }
    protected String appid = DefaultCfg.appid;
    protected String bucket = DefaultCfg.bucket;
    protected String fileid = null;
    protected String httpProtocol = DefaultCfg.httpProtocol;
    protected String serverFlag = DefaultCfg.serverFlag;
    protected String dosmain = DefaultCfg.dosmain;

    protected static byte[] object = new byte[0];
    public static BizServer instance;
    private BizServer(){}

    public static BizServer  getInstance(){
      if(instance == null){
          synchronized(object){
              instance = new BizServer();
          }
      }
        return instance;
    }

    public void setBucket(String bucket){
        this.bucket = bucket;
    }
    public void setFileId(String fileid) {
        this.fileid = urlEncoder(fileid);
    }
    /**
     *对fileID进行URLEncoder编码
     */
    private String  urlEncoder(String fileID){
        if(fileID == null){
            return fileID;
        }
        StringBuilder stringBuilder = new StringBuilder();
        String[] strFiled = fileID.trim().split("/");
        int length = strFiled.length;
        for(int i = 0; i< length; i++){
            if("".equals(strFiled[i]))continue;
            stringBuilder.append("/");
            try{
                String str = URLEncoder.encode(strFiled[i], "utf-8").replace("+","%20");
                stringBuilder.append(str);
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        if(fileID.endsWith("/")) stringBuilder.append("/");
        fileID = stringBuilder.toString();
        return fileID;
    }
    public String getOnceSign(){
        String onceSign = null;
        String cgi = "http://203.195.194.28/cosv4/getsignv4.php?" + "bucket=" +bucket + "&service=cos&expired=0&path=" + fileid;
        try {
            URL url = new URL(cgi);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            InputStream in = conn.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(in));
            String line = bufferedReader.readLine();
            if(line == null)return  null;
            JSONObject json = new JSONObject(line);
            if(json.has("sign")){
                onceSign = json.getString("sign");
            }
            Log.w("XIAO","onceSign =" + onceSign);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return onceSign;
    }

    public String getSign(){
        String sign = null;
        String cgi = "http://203.195.194.28/cosv4/getsignv4.php?" + "bucket=" + bucket + "&service=video";
        try {
            URL url = new URL(cgi);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            InputStream in = conn.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(in));
            String line = bufferedReader.readLine();
            if(line == null)return  null;
            JSONObject json = new JSONObject(line);
            if(json.has("sign")){
                sign = json.getString("sign");
            }
            Log.w("XIAO","sign=" +sign);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return sign;
    }

}
