package com.tencent.cos.qclouddemo;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


import com.tencent.cos.COS;
import com.tencent.cos.COSClient;
import com.tencent.cos.COSClientConfig;
import com.tencent.cos.model.COSAuthority;
import com.tencent.cos.model.COSEndPoint;
import com.tencent.cos.model.COSRequest;
import com.tencent.cos.model.COSResult;
import com.tencent.cos.model.DeleteObjectRequest;
import com.tencent.cos.model.DeleteObjectResult;
import com.tencent.cos.model.GetObjectMetadataRequest;
import com.tencent.cos.model.GetObjectMetadataResult;
import com.tencent.cos.model.PutObjectRequest;
import com.tencent.cos.model.PutObjectResult;
import com.tencent.cos.model.UpdateObjectRequest;
import com.tencent.cos.model.UpdateObjectResult;
import com.tencent.cos.task.listener.ICmdTaskListener;
import com.tencent.cos.task.listener.IUploadTaskListener;
import com.tencent.cos.utils.FileUtils;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class FileUploadActivity extends AppCompatActivity implements View.OnClickListener{

    /** UI */
    private Button addBtn, uploadBtn, deleteBtn, queryBtn, updateBtn, uploadListBtn, uploadConcurrentBtn;
    private TextView urlText, detailText, pathText, progreesText;

    private Handler mainHandler = new Handler(Looper.getMainLooper());
    private static  final int OPENFILE_CODE = 1;


    /** cos */
    COSClient cos;
    COSClientConfig cosConfig;
    String appid = "10006595";
    String bucket = "xy";
    volatile int requestId;
    private String currentPath = null;
    String filename = null;
    String onceSign = null;
    String sign = null;
    BizServer bizServer = BizServer.getInstance();
    String getCosPahtName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_upload);

        addBtn = (Button)findViewById(R.id.add);
        uploadBtn = (Button)findViewById(R.id.upload);
        deleteBtn = (Button)findViewById(R.id.delete);
        queryBtn = (Button)findViewById(R.id.stat);
        updateBtn = (Button)findViewById(R.id.update);
        uploadListBtn = (Button)findViewById(R.id.uploadlist);
        uploadConcurrentBtn = (Button)findViewById(R.id.uploadConcurrent);

        urlText = (TextView)findViewById(R.id.url);
        detailText = (TextView)findViewById(R.id.detail);
        pathText = (TextView)findViewById(R.id.srcPath);
        progreesText = (TextView)findViewById(R.id.progress);

        /** cosclient 配置设置; 根据需要设置；  */
        cosConfig = new COSClientConfig();
        /** 设置园区；根据创建的cos空间时选择的园区
         * 华南园区：COSEndPoint.COS_GZ(已上线)
         * 华北园区：COSEndPoint.COS_TJ(已上线)
         * 华东园区：COSEndPoint.COS_SH
         * 此处Demo中选择了 华东园区：COSEndPoint.COS_SH用于测试
         */
        cosConfig.setEndPoint(COSEndPoint.COS_SH);
        cos = new COSClient(this,appid,cosConfig,"file_qcloud");

        addBtn.setOnClickListener(this);
        uploadBtn.setOnClickListener(this);
        deleteBtn.setOnClickListener(this);
        queryBtn.setOnClickListener(this);
        updateBtn.setOnClickListener(this);
        uploadListBtn.setOnClickListener(this);
        uploadConcurrentBtn.setOnClickListener(this);
        urlText.setOnClickListener(this);


    }


    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch(id){
            case R.id.add:
                onAdd();
                break;
            case R.id.upload:
                upload();
                break;
            case R.id.delete:
                delete();
                break;
            case R.id.stat:
                query();
                break;
            case R.id.update:
                update();
                break;
            case R.id.url:
                download();
                break;
            case R.id.uploadlist:
                uploadList();
                break;
            case R.id.uploadConcurrent:
                uploadConcurrent();
                break;
            default:
                break;
        }
    }

    public void download(){
        String url = urlText.getText().toString().trim();
        if(TextUtils.isEmpty(url)){
            Toast.makeText(this,"下载地址为空",Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent();
        intent.putExtra("url",url);
        intent.setClass(this,FileDownloadActivity.class);
        startActivity(intent);
    }

    public void update(){
        final EditText editText = new EditText(FileUploadActivity.this);
        AlertDialog.Builder builder = new AlertDialog.Builder(FileUploadActivity.this);
        builder.setTitle("请输入文件夹路径");
        builder.setView(editText);
        builder.setPositiveButton("确认",new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which) {
                getCosPahtName = editText.getText().toString().trim();
                update(getCosPahtName);
            }
        });
        builder.setNegativeButton("取消",new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void update(final String getCosPahtName){
        new Thread(new Runnable() {
            @Override
            public void run() {
                if(TextUtils.isEmpty(getCosPahtName)){
                    Toast.makeText(FileUploadActivity.this,"文件名为空",Toast.LENGTH_SHORT).show();
                    return;
                }
                Map<String, String> customer = new LinkedHashMap<String, String>();
                customer.put("Cache-Control","no-cache");
                customer.put("Content-Disposition","attachment");
                customer.put("Content-Language","content=\"zh-cn\"");
                customer.put("x-cos-meta-","自定义属性");
                String biz_attr = "文件属性更新";
                String authority = COSAuthority.EINVALID;
                String cosPath = getCosPahtName;
                bizServer.setBucket(bucket);
                bizServer.setFileId("/" + cosPath);
                onceSign = bizServer.getOnceSign();
                UpdateObjectRequest updateObjectRequest = new UpdateObjectRequest();
                updateObjectRequest.setBucket(bucket);
                updateObjectRequest.setCosPath("/"+cosPath);
                updateObjectRequest.setSign(onceSign);
                updateObjectRequest.setBizAttr(biz_attr);
                updateObjectRequest.setAuthority(authority);
                updateObjectRequest.setCustomHeader(customer);
                updateObjectRequest.setListener(new ICmdTaskListener() {
                    @Override
                    public void onSuccess(COSRequest cosRequest, COSResult cosResult) {
                        Log.w("XIAO", cosResult.code+" : "+cosResult.msg);
                    }

                    @Override
                    public void onFailed(COSRequest COSRequest, COSResult cosResult) {
                        Log.w("XIAO", cosResult.code+" : "+cosResult.msg);
                    }
                });
                /*
                UpdateObjectRequest updateObjectRequest = new UpdateObjectRequest(appid,bucket,"/"+cosPath,
                        onceSign ,"文件属性更新",
                        null,customer, null);
                 */
                requestId = updateObjectRequest.getRequestId();
                UpdateObjectResult updateObjectResult = cos.updateObject(updateObjectRequest);
                if (updateObjectResult!=null) {
                    Log.w("XIAO", updateObjectResult.code+" : "+updateObjectResult.msg);
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("更新结果： ret ="  + updateObjectResult.code + "; msg =" + updateObjectResult.msg );
                    final String strResult = stringBuilder.toString();
                    mainHandler.post(new Runnable(){
                        @Override
                        public void run() {
                            detailText.setText(strResult);
                        }
                    });
                }
            }
        }).start();
    }

    public void query(){
        final EditText editText = new EditText(FileUploadActivity.this);
        AlertDialog.Builder builder = new AlertDialog.Builder(FileUploadActivity.this);
        builder.setTitle("请输入文件夹路径");
        builder.setView(editText);
        builder.setPositiveButton("确认",new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which) {
                getCosPahtName = editText.getText().toString().trim();
                query(getCosPahtName);
            }
        });
        builder.setNegativeButton("取消",new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void query(final String getCosPahtName){
        new Thread(new Runnable() {
            @Override
            public void run() {
                if(TextUtils.isEmpty(getCosPahtName)){
                    Toast.makeText(FileUploadActivity.this,"文件名为空",Toast.LENGTH_SHORT).show();
                    return;
                }
                String cosPath = getCosPahtName;
                Log.w("XIAO",cosPath);
                bizServer.setBucket(bucket);
                sign = bizServer.getSign();
                GetObjectMetadataRequest getObjectMetadataRequest = new GetObjectMetadataRequest();
                getObjectMetadataRequest.setBucket(bucket);
                getObjectMetadataRequest.setCosPath("/" + cosPath);
                getObjectMetadataRequest.setSign(sign);
                getObjectMetadataRequest.setListener(new ICmdTaskListener() {
                    @Override
                    public void onSuccess(COSRequest cosRequest, COSResult cosResult) {
                        GetObjectMetadataResult getObjectMetadataResult = (GetObjectMetadataResult) cosResult;
                        if(getObjectMetadataResult!=null){
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("查询结果 = "+
                                    getObjectMetadataResult.code + "," +
                                    getObjectMetadataResult.msg  + "," +
                                    getObjectMetadataResult.mtime + "," +
                                    getObjectMetadataResult.ctime + "," +
                                    getObjectMetadataResult.filesize + "," +
                                    getObjectMetadataResult.access_url+ "," +
                                    getObjectMetadataResult.sha + "," +
                                    getObjectMetadataResult.authority + "," +
                                    getObjectMetadataResult.biz_attr + "\n" +
                                    getObjectMetadataResult.custom_headers);
                            final String strResult = stringBuilder.toString();
                            Log.w("XIAO","strResult =" +strResult ==null?"null":strResult);
                            mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    detailText.setText(strResult);
                                }
                            });
                        }
                    }

                    @Override
                    public void onFailed(COSRequest cosRequest, final COSResult cosResult) {
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                detailText.setText("查询出错： ret =" +cosResult.code + "; msg =" + cosResult.msg);
                            }
                        });
                    }

                });
                /*
                GetObjectMetadataRequest getObjectMetadataRequest = new GetObjectMetadataRequest(appid, bucket, "/" + cosPath, sign, new ICmdTaskListener() {
                    @Override
                    public void onSuccess(COSRequest cosRequest, COSResult cosResult) {
                        GetObjectMetadataResult getObjectMetadataResult = (GetObjectMetadataResult) cosResult;
                        if(getObjectMetadataResult!=null){
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("查询结果 = "+
                                    getObjectMetadataResult.code + "," +
                                    getObjectMetadataResult.msg  + "," +
                                    getObjectMetadataResult.mtime + "," +
                                    getObjectMetadataResult.ctime + "," +
                                    getObjectMetadataResult.filesize + "," +
                                    getObjectMetadataResult.access_url+ "," +
                                    getObjectMetadataResult.sha + "," +
                                    getObjectMetadataResult.biz_attr + "\n" +
                                    getObjectMetadataResult.custom_headers);
                            final String strResult = stringBuilder.toString();
                            Log.w("XIAO","strResult =" +strResult ==null?"null":strResult);
                            mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    detailText.setText(strResult);
                                }
                            });
                        }
                    }

                    @Override
                    public void onFailed(COSRequest cosRequest, final COSResult cosResult) {
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                detailText.setText("查询出错： ret =" +cosResult.code + "; msg =" + cosResult.msg);
                            }
                        });
                    }

                });
                */
                requestId = getObjectMetadataRequest.getRequestId();
                GetObjectMetadataResult getObjectMetadataResult = cos.getObjectMetadata(getObjectMetadataRequest);

            }
        }).start();
    }

  public void delete(){
      final EditText editText = new EditText(FileUploadActivity.this);
      AlertDialog.Builder builder = new AlertDialog.Builder(FileUploadActivity.this);
      builder.setTitle("请输入文件夹路径");
      builder.setView(editText);
      builder.setPositiveButton("确认",new DialogInterface.OnClickListener(){

          @Override
          public void onClick(DialogInterface dialog, int which) {
              getCosPahtName = editText.getText().toString().trim();
              delete(getCosPahtName);
          }
      });
      builder.setNegativeButton("取消",new DialogInterface.OnClickListener(){
          @Override
          public void onClick(DialogInterface dialog, int which) {
              dialog.cancel();
          }
      });
      AlertDialog dialog = builder.create();
      dialog.show();
  }
    public void delete(final String getCosPahtName){
        new Thread(new Runnable() {
            @Override
            public void run() {
                if(TextUtils.isEmpty(getCosPahtName)){
                    Toast.makeText(FileUploadActivity.this,"文件为空",Toast.LENGTH_SHORT).show();
                    return;
                }
                String cosPath = getCosPahtName;
                bizServer.setBucket(bucket);
                bizServer.setFileId("/" + cosPath);
                onceSign = bizServer.getOnceSign();
                DeleteObjectRequest deleteObjectRequest = new DeleteObjectRequest();
                deleteObjectRequest.setBucket(bucket);
                deleteObjectRequest.setCosPath("/" + cosPath);
                deleteObjectRequest.setSign(onceSign);
                deleteObjectRequest.setListener(new ICmdTaskListener() {
                    @Override
                    public void onSuccess(COSRequest cosRequest, COSResult cosResult) {
                        Log.w("XIAO", cosResult.code+" : "+cosResult.msg);
                    }

                    @Override
                    public void onFailed(COSRequest COSRequest, COSResult cosResult) {
                        Log.w("XIAO", cosResult.code+" : "+cosResult.msg);
                    }
                });

                /*
                DeleteObjectRequest DeleteObjectRequest = new DeleteObjectRequest(appid, bucket, "/" + cosPath,
                        onceSign, new ICmdTaskListener() {
                    @Override
                    public void onSuccess(COSRequest cosRequest, COSResult cosResult) {

                    }

                    @Override
                    public void onFailed(COSRequest COSRequest, COSResult cosResult) {

                    }
                });
                */
                requestId = deleteObjectRequest.getRequestId();
                DeleteObjectResult deleteObjectResult = cos.deleteObject(deleteObjectRequest);
                if (deleteObjectResult!=null) {
                    Log.w("XIAO", deleteObjectResult.code+" : "+deleteObjectResult.msg);
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(deleteObjectResult.code+" : "+deleteObjectResult.msg);
                    final String strResult = stringBuilder.toString();
                    mainHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            detailText.setText(strResult);
                        }
                    });
                }

            }
        }).start();
    }

    /**
     * 1)根目录下上传单个文件   filename
     * 2）子目录下上传单个文件  test/filename
     * 3）依次上传多个文件       参考一键上传
     * 4）同目录下上传相同的文件
     * 5）删除文件后上传相同的文件
     */
    public void upload(){
        final EditText editText = new EditText(FileUploadActivity.this);
        AlertDialog.Builder builder = new AlertDialog.Builder(FileUploadActivity.this);
        builder.setTitle("请输入cos文件夹路径");
        builder.setView(editText);
        builder.setPositiveButton("确认",new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which) {
                getCosPahtName = editText.getText().toString().trim();
                upload(getCosPahtName);
            }
        });
        builder.setNegativeButton("取消",new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void upload(final String getCosPahtName){
        new Thread() {
            @Override
            public void run() {
                String srcPath = currentPath;
                if(TextUtils.isEmpty(srcPath)){
                    Toast.makeText(FileUploadActivity.this,"请选择文件",Toast.LENGTH_SHORT).show();
                    return;
                }
                String filename = FileUtils.getFileName(srcPath);
                String cosPath;
                if(TextUtils.isEmpty(getCosPahtName)){
                    cosPath = filename;
                }else{
                    cosPath = getCosPahtName + "/" + filename;
                }
                bizServer.setBucket(bucket);
                String sign = bizServer.getSign();
                PutObjectRequest putObjectRequest = new PutObjectRequest();
                putObjectRequest.setBucket(bucket);
                putObjectRequest.setCosPath(cosPath);
                putObjectRequest.setSrcPath(srcPath);
                putObjectRequest.setSign(sign);
                putObjectRequest.setInsertOnly("1");
                //putObjectRequest.setSlice_size(1024*1024);
                //putObjectRequest.setSliceFlag(true);
                putObjectRequest.setListener(new  IUploadTaskListener(){
                    @Override
                    public void onSuccess(COSRequest cosRequest, COSResult cosResult) {

                        PutObjectResult result = (PutObjectResult) cosResult;
                        if(result != null){
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append(" 上传结果： ret=" + result.code + "; msg =" +result.msg + "\n");
                            stringBuilder.append(" access_url= " + result.access_url == null ? "null" :result.access_url + "\n");
                            stringBuilder.append(" resource_path= " + result.resource_path == null ? "null" :result.resource_path + "\n");
                            stringBuilder.append(" url= " + result.url == null ? "null" :result.url);
                            final String strResult = stringBuilder.toString();
                            final String url = result.access_url == null ? "null" :result.access_url;
                            mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    detailText.setText(strResult);
                                    urlText.setText(url);
                                }
                            });
                        }
                    }

                    @Override
                    public void onFailed(COSRequest COSRequest, final COSResult cosResult) {
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                detailText.setText("上传出错： ret =" +cosResult.code + "; msg =" + cosResult.msg);
                            }
                        });
                    }

                    @Override
                    public void onProgress(COSRequest cosRequest, final long currentSize, final long totalSize) {
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                float progress = (float)currentSize/totalSize;
                                progress = progress *100;
                                progreesText.setText("进度：  " + (int)progress + "%");
                            }
                        });
                    }
                });
                /*
                //
                PutObjectRequest putObjectRequest = new PutObjectRequest(appid,
                        bucket, cosPath, srcPath, sign, new IUploadTaskListener(){
                    @Override
                    public void onSuccess(COSRequest cosRequest, COSResult cosResult) {

                        PutObjectResult result = (PutObjectResult) cosResult;
                        if(result != null){
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("上传结果： ret=" + result.code + "; msg =" +result.msg + "\n");
                            stringBuilder.append(" access_url= " + result.access_url == null ? "null" :result.access_url + "\n");
                            stringBuilder.append(" resource_path= " + result.resource_path == null ? "null" :result.resource_path + "\n");
                            stringBuilder.append(" url= " + result.url == null ? "null" :result.url);
                            final String strResult = stringBuilder.toString();
                            final String url = result.access_url == null ? "null" :result.access_url;
                            mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    detailText.setText(strResult);
                                    urlText.setText(url);
                                }
                            });
                        }
                    }

                    @Override
                    public void onFailed(COSRequest COSRequest, final COSResult cosResult) {
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                detailText.setText("上传出错： ret =" +cosResult.code + "; msg =" + cosResult.msg);
                            }
                        });
                    }

                    @Override
                    public void onProgress(COSRequest cosRequest, final long currentSize, final long totalSize) {
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                float progress = (float)currentSize/totalSize;
                                progress = progress *100;
                                progreesText.setText("进度：  " + (int)progress + "%");
                            }
                        });
                    }
                });
                 */
                requestId = putObjectRequest.getRequestId();
                PutObjectResult putObjectResult = cos.putObject(putObjectRequest);
            }
        }.start();
    }

    public void uploadList(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                List<String> listPath = new ArrayList<String>();
                String[] columns = { MediaStore.Images.Media.DATA,MediaStore.Images.Media._ID };
                String orderBy = MediaStore.Images.Media.DATE_TAKEN;
                Cursor imagecursor = FileUploadActivity.this.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,columns,null,null,orderBy + " DESC");
                if(imagecursor != null){
                    Log.w("XIAO","count =" + imagecursor.getCount());
                    int len = imagecursor.getCount() > 10 ? 10 : imagecursor.getCount();
                    int index = 0;
                    for(int i = 0; i< len; i++){
                        imagecursor.moveToPosition(i);
                        index = imagecursor.getColumnIndex(MediaStore.Images.Media.DATA);
                        listPath.add(imagecursor.getString(index));
                    }
                    imagecursor.close();
                }
                bizServer.setBucket(bucket);
                sign = bizServer.getSign();
                mainHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        detailText.setText("");
                    }
                });
                String cosPath = null;
                PutObjectRequest putObjectRequest = null;
                for(int i = 0;i < listPath.size(); i++) {
                    cosPath ="test/" + FileUtils.getFileName(listPath.get(i));
                    Log.w("XIAO" , "srcPath=" + listPath.get(i));
                    putObjectRequest = new PutObjectRequest(appid, bucket, cosPath, listPath.get(i), sign, new IUploadTaskListener() {
                        @Override
                        public void onProgress(COSRequest request, final long currentSize, final long totalSize) {
                            mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    float progress = (float) currentSize / totalSize;
                                    progress = progress * 100;
                                    progreesText.setText("进度：  " + (int) progress + "%");
                                }
                            });
                        }

                        @Override
                        public void onSuccess(COSRequest request, COSResult cosResult) {

                            PutObjectResult result = (PutObjectResult) cosResult;
                            if (result != null) {
                                StringBuilder stringBuilder = new StringBuilder();
                                stringBuilder.append("上传结果： ret=" + result.code + "; msg =" + result.msg + "\n");
                                stringBuilder.append(" access_url= " + result.access_url == null ? "null" : result.access_url + "\n");
                                final String strResult = stringBuilder.toString();
                                mainHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        detailText.setText(detailText.getText().toString() + "/n" +strResult);
                                    }
                                });
                            }
                        }

                        @Override
                        public void onFailed(COSRequest request, final COSResult cosResult) {
                            mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    detailText.setText(detailText.getText().toString() + "\n" +"上传出错： ret =" + cosResult.code + "; msg =" + cosResult.msg);
                                }
                            });
                        }
                    });
                    requestId = putObjectRequest.getRequestId();
                    cos.putObject(putObjectRequest);
                }

            }
        }).start();

    }
    public void uploadConcurrent() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                List<String>listPath = new ArrayList<>();
                String[] columns = { MediaStore.Images.Media.DATA,MediaStore.Images.Media._ID };
                String orderBy = MediaStore.Images.Media.DATE_TAKEN;
                Cursor imagecursor = FileUploadActivity.this.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,columns,null,null,orderBy + " DESC");
                if(imagecursor != null){
                    Log.w("XIAO","count =" + imagecursor.getCount());
                    int len = imagecursor.getCount() > 4 ? 4 : imagecursor.getCount();
                    int index = 0;
                    for(int i = 0; i< len; i++){
                        imagecursor.moveToPosition(i);
                        index = imagecursor.getColumnIndex(MediaStore.Images.Media.DATA);
                        listPath.add(imagecursor.getString(index));
                    }
                    imagecursor.close();
                }
                String getCosPahtName = "test";
                for(int i = 0; i< listPath.size(); i ++){
                    upload(listPath.get(i),getCosPahtName);
                }
            }
        }).start();
    }
    public void upload(final String srcPath, final String getCosPahtName){
        new Thread(new Runnable() {
            @Override
            public void run() {
                if(TextUtils.isEmpty(srcPath)){
                    Toast.makeText(FileUploadActivity.this,"请选择文件",Toast.LENGTH_SHORT).show();
                    return;
                }
                String filename = FileUtils.getFileName(srcPath);
                String cosPath;
                if(TextUtils.isEmpty(getCosPahtName)){
                    cosPath = filename;
                }else{
                    cosPath = getCosPahtName + "/" + filename;
                }
                bizServer.setBucket(bucket);
                String sign = bizServer.getSign();
                PutObjectRequest putObjectRequest = new PutObjectRequest(appid,
                        bucket, cosPath, srcPath, sign, new IUploadTaskListener(){
                    @Override
                    public void onSuccess(COSRequest cosRequest, COSResult cosResult) {

                        PutObjectResult result = (PutObjectResult) cosResult;
                        if(result != null){
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.append("上传结果： ret=" + result.code + "; msg =" +result.msg + "\n");
                            stringBuilder.append(" access_url= " + result.access_url == null ? "null" :result.access_url + "\n");
                            stringBuilder.append(" resource_path= " + result.resource_path == null ? "null" :result.resource_path + "\n");
                            stringBuilder.append(" url= " + result.url == null ? "null" :result.url);
                            final String strResult = stringBuilder.toString();
                            final String url = result.access_url == null ? "null" :result.access_url;
                            mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                   Log.w("XIAO","url =" + url);
                                }
                            });
                        }
                    }

                    @Override
                    public void onFailed(COSRequest COSRequest, final COSResult cosResult) {
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                Log.w("XIAO","上传出错： ret =" +cosResult.code + "; msg =" + cosResult.msg);
                            }
                        });
                    }

                    @Override
                    public void onProgress(final COSRequest cosRequest, final long currentSize, final long totalSize) {
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                float progress = (float)currentSize/totalSize;
                                progress = progress *100;
                                Log.w("XIAO","进度：  " + (int)progress + "%" + cosRequest.getCosPath());
                            }
                        });
                    }
                });
                requestId = putObjectRequest.getRequestId();
                PutObjectResult putObjectResult = cos.putObject(putObjectRequest);
            }}).start();
    }

    public void onAdd(){
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent,OPENFILE_CODE);
    }

    public String getPath(Context context, Uri uri){
        if("content".equalsIgnoreCase(uri.getScheme())){
            String [] projection = {MediaStore.MediaColumns.DATA};
            String colum_name = "_data";
            Cursor cursor = null;
            try{
                cursor = context.getContentResolver().query(uri,projection,null,null,null);
                Log.w("XIAO","count =" +cursor.getCount());
                if(cursor != null && cursor.moveToFirst()){
                    int colum_index = cursor.getColumnIndex(colum_name);
                    return cursor.getString(colum_index);
                }
            }catch (Exception e){
                Log.w("XIAO",e.getMessage(),e);
            }finally {
                if(cursor != null){
                    cursor.close();
                }
            }
        }else if("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }else {
            Toast.makeText(this, "选择文件路径为空", Toast.LENGTH_SHORT).show();
        }
        return null;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        if(resultCode != Activity.RESULT_OK || data == null){
            return;
        }
        switch(requestCode){
            case OPENFILE_CODE:
                Uri uri = data.getData();
                currentPath = getPath(this, uri);
                pathText.setText(currentPath);
                break;
            default:
                break;
        }
    }
}
