package com.tencent.cos.qclouddemo;

import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.tencent.cos.COS;
import com.tencent.cos.COSClient;
import com.tencent.cos.COSClientConfig;
import com.tencent.cos.model.COSEndPoint;
import com.tencent.cos.model.COSRequest;
import com.tencent.cos.model.COSResult;
import com.tencent.cos.model.GetObjectRequest;
import com.tencent.cos.task.listener.IDownloadTaskListener;

public class FileDownloadActivity extends AppCompatActivity implements View.OnClickListener{

    private Button downloadBtn, pauseBtn, cancelBtn, resumeBtn;
    private TextView urlText, localText, progressText;

    private Handler mainHandler = new Handler(Looper.getMainLooper());

    /** cos */
    COSClient cos;
    COSClientConfig cosConfig;
    String appid = "10006595";
    String bucket = "xy";
    volatile int requestId;
    private String localPath = null;
    String url = null;
    String sign = null;

    BizServer bizServer = BizServer.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_download);
        downloadBtn = (Button) findViewById(R.id.download);
        pauseBtn = (Button) findViewById(R.id.pause);
        cancelBtn = (Button) findViewById(R.id.cancel);
        resumeBtn = (Button) findViewById(R.id.resume);

        urlText = (TextView) findViewById(R.id.url);
        localText = (TextView) findViewById(R.id.localPath);
        progressText = (TextView) findViewById(R.id.progress);

        downloadBtn.setOnClickListener(this);
        cancelBtn.setOnClickListener(this);
        pauseBtn.setOnClickListener(this);
        resumeBtn.setOnClickListener(this);

        /** cosclient 配置设置; 根据需要设置；  */
        cosConfig = new COSClientConfig();
        /** 设置园区；根据创建的cos空间时选择的园区
         * 华南园区：COSEndPoint.COS_GZ(已上线)
         * 华北园区：COSEndPoint.COS_TJ(已上线)
         * 华东园区：COSEndPoint.COS_SH
         * 此处Demo中选择了 华东园区：COSEndPoint.COS_SH用于测试
         */
        cosConfig.setEndPoint(COSEndPoint.COS_SH);
        cos = new COSClient(this,appid,cosConfig,"file_download_qcloud");
        url = getIntent().getStringExtra("url");
        urlText.setText(url);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch(id){
            case R.id.download:
                onDownload();
                break;
            case R.id.pause:
                pause();
                break;
            case R.id.resume:
                resume();
                break;
            case R.id.cancel:
                cancel();
                break;
            default:
                break;
        }
    }

    private void cancel() {
    }

    private void resume() {
    }

    private void pause() {
    }

    private void onDownload() {
        final String savePath = Environment.getExternalStorageDirectory().getAbsolutePath();
        localText.setText(savePath);


        new Thread(new Runnable(){
            @Override
            public void run() {
                String downloadURl = url;
                downloadURl = "https://m.dianping.com/oscms/content/%E5%A4%B4%E5%9B%BE3_meitu_1.jpg";
                bizServer.setBucket(bucket);
                sign = bizServer.getSign();
                GetObjectRequest getObjectRequest = new GetObjectRequest(downloadURl,savePath);
                getObjectRequest.setSign(null);
                getObjectRequest.setListener(new IDownloadTaskListener() {
                    @Override
                    public void onProgress(COSRequest cosRequest, final long currentSize, final long totalSize) {
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                float progress =  currentSize / (float)totalSize;
                                progress = progress * 100;
                                progressText.setText("progress =" + (int) (progress) + "%");
                                Log.w("XIAO", "progress =" + (int) (progress) + "%");
                            }
                        });
                    }

                    @Override
                    public void onSuccess(COSRequest cosRequest, COSResult cosResult) {
                        Log.w("XIAO","code =" + cosResult.code + "; msg =" + cosResult.msg);
                    }

                    @Override
                    public void onFailed(COSRequest COSRequest, COSResult cosResult) {
                        Log.w("XIAO","code =" + cosResult.code + "; msg =" + cosResult.msg);
                    }
                });
                /*
                GetObjectRequest getObjectRequest = new GetObjectRequest(downloadURl,savePath,null,new IDownloadTaskListener(){

                    @Override
                    public void onSuccess(COSRequest cosRequest, COSResult cosResult) {
                        Log.w("XIAO","code =" + cosResult.code + "; msg =" + cosResult.msg);
                    }

                    @Override
                    public void onFailed(COSRequest cosRequest, COSResult cosResult) {
                        Log.w("XIAO","code =" + cosResult.code + "; msg =" + cosResult.msg);
                    }

                    @Override
                    public void onProgress(COSRequest cosRequest, final long currentSize, final long totalSize) {
                        mainHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                float progress =  currentSize / (float)totalSize;
                                progress = progress * 100;
                                progressText.setText("progress =" + (int) (progress) + "%");
                                Log.w("XIAO", "progress =" + (int) (progress) + "%");
                            }
                        });
                    }
                });
                */
                requestId = getObjectRequest.getRequestId();
                cos.getObject(getObjectRequest);
            }
        }).start();
    }
}
