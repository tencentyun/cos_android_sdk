package com.tencent.cos.qclouddemo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;


public class MainActivity extends AppCompatActivity {

    Button fileBtn;
    Button dirBtn;
    Button otherBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fileBtn = (Button)findViewById(R.id.file);
        dirBtn = (Button)findViewById(R.id.dir);
        otherBtn = (Button)findViewById(R.id.other);

        fileBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.w("XIAO","测试");
                Intent intent = new Intent();
                intent.setClass(MainActivity.this, FileUploadActivity.class);
                startActivity(intent);

            }
        });
        dirBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.w("XIAO","测试");
                Intent intent = new Intent();
                intent.setClass(MainActivity.this, DirActivity.class);
                startActivity(intent);
            }
        });
        otherBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.w("XIAO","测试");
                Intent intent = new Intent();
                intent.setClass(MainActivity.this, OtherActivity.class);
                startActivity(intent);
            }
        });

    }
}
